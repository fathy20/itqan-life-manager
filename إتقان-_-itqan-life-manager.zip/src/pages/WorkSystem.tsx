import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  Briefcase, 
  Plus, 
  Filter, 
  Clock, 
  CheckCircle2, 
  Circle, 
  MoreVertical,
  AlertCircle,
  ExternalLink,
  Zap,
  Calendar,
  Target,
  Timer
} from 'lucide-react';
import { cn } from '../lib/utils';
import { format } from 'date-fns';
import { ar } from 'date-fns/locale';

const WorkSystem: React.FC = () => {
  const { state } = useApp();
  const [filter, setFilter] = useState<'all' | 'work' | 'freelance' | 'study'>('all');

  const filteredTasks = state.tasks.filter(t => filter === 'all' || t.type === filter);

  return (
    <div className="space-y-8">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">إدارة العمل والمشاريع</h2>
          <p className="text-white/50 mt-1">تتبع مهامك الوظيفية، مشاريع الفريلانس، ومسارك المهني.</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="bg-white/5 p-1 rounded-xl border border-white/10 flex overflow-x-auto">
            {[
              { id: 'all', label: 'الكل' },
              { id: 'work', label: 'وظيفة' },
              { id: 'freelance', label: 'فريلانس' },
              { id: 'study', label: 'تعلم' },
            ].map(item => (
              <button
                key={item.id}
                onClick={() => setFilter(item.id as any)}
                className={cn(
                  "px-4 py-2 rounded-lg text-xs font-bold transition-all whitespace-nowrap",
                  filter === item.id ? "bg-brand-500 text-white shadow-lg" : "text-white/40 hover:text-white/60"
                )}
              >
                {item.label}
              </button>
            ))}
          </div>
          <button className="glass-button p-3 text-brand-400">
            <Plus size={20} />
          </button>
        </div>
      </header>

      {/* Career Track Section */}
      <section className="space-y-4">
        <h3 className="text-xl font-bold flex items-center gap-2">
          <Target className="text-brand-400" />
          المسار المهني (Career Track)
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {state.courses.map(course => (
            <div key={course.id} className="glass-card p-6 relative overflow-hidden group">
              <div className="absolute top-0 right-0 w-32 h-32 bg-brand-500/5 rounded-full -mr-16 -mt-16 blur-3xl group-hover:bg-brand-500/10 transition-all" />
              <div className="flex justify-between items-start mb-6">
                <div>
                  <h4 className="font-bold text-lg">{course.name}</h4>
                  <p className="text-xs text-white/40">{course.platform}</p>
                </div>
                <div className="p-2 rounded-lg bg-white/5" style={{ color: course.color }}>
                  <Zap size={18} />
                </div>
              </div>
              <div className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between text-xs">
                    <span className="text-white/40">التقدم الكلي</span>
                    <span className="font-bold">
                      {course.totalHours > 0 ? Math.round((course.completedHours / course.totalHours) * 100) : 0}%
                    </span>
                  </div>
                  <div className="h-1.5 bg-white/5 rounded-full overflow-hidden">
                    <div 
                      className="h-full transition-all duration-500" 
                      style={{ 
                        width: `${course.totalHours > 0 ? (course.completedHours / course.totalHours) * 100 : 0}%`, 
                        backgroundColor: course.color 
                      }} 
                    />
                  </div>
                </div>
                <div className="flex items-center justify-between text-[10px]">
                  <span className="text-white/40">الهدف الأسبوعي: <span className="text-white font-bold">{course.weeklyGoalHours} س</span></span>
                  <span className="text-white/40">المنجز: <span className="text-white font-bold">{course.completedHours} س</span></span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Projects Overview */}
      <section className="space-y-4">
        <h3 className="text-xl font-bold flex items-center gap-2">
          <Briefcase className="text-sky-400" />
          المشاريع النشطة
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {state.projects.map(project => (
            <div key={project.id} className="glass-card p-6 border-l-4" style={{ borderLeftColor: project.color }}>
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="font-bold text-lg">{project.name}</h3>
                  <p className="text-xs text-white/40">{project.client || 'مشروع داخلي'}</p>
                </div>
                <div className="p-2 rounded-lg bg-white/5">
                  <Briefcase size={18} className="text-white/40" />
                </div>
              </div>
              <div className="space-y-2">
                <div className="flex justify-between text-xs">
                  <span className="text-white/40">الحالة</span>
                  <span className="font-bold text-emerald-400">{project.status}</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-white/40">الأولوية</span>
                  <span className={cn(
                    "font-bold",
                    project.priority === 'high' ? "text-red-400" : "text-blue-400"
                  )}>{project.priority}</span>
                </div>
              </div>
            </div>
          ))}
          <button className="glass-card p-6 border-dashed border-2 border-white/10 flex flex-col items-center justify-center gap-2 text-white/40 hover:text-white/60 transition-all">
            <Plus size={24} />
            <span className="text-sm font-bold">إضافة مشروع جديد</span>
          </button>
        </div>
      </section>

      {/* Tasks List */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-xl font-bold">قائمة المهام</h3>
          <button className="text-brand-400 text-xs font-bold flex items-center gap-1">
            <Filter size={14} />
            تصفية متقدمة
          </button>
        </div>

        <div className="space-y-3">
          {filteredTasks.map(task => (
            <div key={task.id} className="glass-card p-4 flex items-center gap-4 group hover:bg-white/[0.04] transition-all">
              <button className="text-white/20 hover:text-brand-400 transition-colors">
                {task.status === 'completed' ? <CheckCircle2 size={24} className="text-emerald-500" /> : <Circle size={24} />}
              </button>
              
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <h4 className={cn(
                    "font-bold truncate",
                    task.status === 'completed' && "text-white/20 line-through"
                  )}>
                    {task.title}
                  </h4>
                  <span className={cn(
                    "text-[10px] px-2 py-0.5 rounded font-bold uppercase",
                    task.type === 'work' ? "bg-blue-500/10 text-blue-400" : 
                    task.type === 'freelance' ? "bg-emerald-500/10 text-emerald-400" :
                    "bg-purple-500/10 text-purple-400"
                  )}>
                    {task.type === 'work' ? 'وظيفة' : task.type === 'freelance' ? 'فريلانس' : 'تعلم'}
                  </span>
                  {task.focusType && (
                    <span className="text-[10px] text-white/30 border border-white/10 px-1.5 rounded">
                      {task.focusType} focus
                    </span>
                  )}
                </div>
                
                <div className="flex items-center gap-4 mt-1">
                  {task.dueDate && (
                    <div className="flex items-center gap-1 text-[10px] text-brand-400 font-bold">
                      <Calendar size={12} />
                      تاريخ الاستحقاق: {format(new Date(task.dueDate), 'd MMM', { locale: ar })}
                    </div>
                  )}
                  {task.deadline && (
                    <div className="flex items-center gap-1 text-[10px] text-white/30">
                      <Clock size={12} />
                      الموعد النهائي: {format(new Date(task.deadline), 'd MMMM', { locale: ar })}
                    </div>
                  )}
                  {task.estimatedMinutes && (
                    <div className="flex items-center gap-1 text-[10px] text-white/30">
                      <Timer size={12} />
                      {task.estimatedMinutes} دقيقة
                    </div>
                  )}
                  {task.priority === 'high' && (
                    <div className="flex items-center gap-1 text-[10px] text-red-400 font-bold">
                      <AlertCircle size={12} />
                      أولوية قصوى
                    </div>
                  )}
                </div>
              </div>

              <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                <button className="p-2 hover:bg-white/5 rounded-lg text-white/40 hover:text-white">
                  <ExternalLink size={16} />
                </button>
                <button className="p-2 hover:bg-white/5 rounded-lg text-white/40 hover:text-white">
                  <MoreVertical size={16} />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default WorkSystem;
