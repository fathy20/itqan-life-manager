import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  ChevronLeft, 
  ChevronRight, 
  Calendar as CalendarIcon,
  Clock,
  Plus
} from 'lucide-react';
import { 
  format, 
  addMonths, 
  subMonths, 
  startOfMonth, 
  endOfMonth, 
  startOfWeek, 
  endOfWeek, 
  isSameMonth, 
  isSameDay, 
  addDays, 
  eachDayOfInterval 
} from 'date-fns';
import { ar } from 'date-fns/locale';
import { cn } from '../lib/utils';

const CalendarView: React.FC = () => {
  const { state } = useApp();
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState(new Date());

  const nextMonth = () => setCurrentMonth(addMonths(currentMonth, 1));
  const prevMonth = () => setCurrentMonth(subMonths(currentMonth, 1));

  const renderHeader = () => {
    return (
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-3xl font-bold">{format(currentMonth, 'MMMM yyyy', { locale: ar })}</h2>
          <p className="text-white/50 mt-1">جدولك الزمني المتكامل لكل الأنشطة.</p>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex bg-white/5 p-1 rounded-xl border border-white/10">
            <button onClick={prevMonth} className="p-2 hover:bg-white/10 rounded-lg transition-colors">
              <ChevronRight size={20} />
            </button>
            <button onClick={() => setCurrentMonth(new Date())} className="px-4 py-2 text-xs font-bold hover:bg-white/10 rounded-lg transition-colors">
              اليوم
            </button>
            <button onClick={nextMonth} className="p-2 hover:bg-white/10 rounded-lg transition-colors">
              <ChevronLeft size={20} />
            </button>
          </div>
          <button className="bg-brand-500 hover:bg-brand-600 text-white p-3 rounded-xl transition-all">
            <Plus size={20} />
          </button>
        </div>
      </div>
    );
  };

  const renderDays = () => {
    const days = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
    return (
      <div className="grid grid-cols-7 mb-4">
        {days.map(day => (
          <div key={day} className="text-center text-[10px] font-bold uppercase text-white/30 tracking-wider">
            {day}
          </div>
        ))}
      </div>
    );
  };

  const renderCells = () => {
    const monthStart = startOfMonth(currentMonth);
    const monthEnd = endOfMonth(monthStart);
    const startDate = startOfWeek(monthStart);
    const endDate = endOfWeek(monthEnd);

    const calendarDays = eachDayOfInterval({ start: startDate, end: endDate });

    const getEventsForDay = (day: Date) => {
      const events: any[] = [];
      const dateStr = format(day, 'yyyy-MM-dd');

      (state.subjects || []).forEach(s => {
        if (s && s.examDate === dateStr) events.push({ type: 'exam', title: `امتحان: ${s.name}`, color: s.color });
      });

      (state.tasks || []).forEach(t => {
        if (t && t.deadline === dateStr) events.push({ type: 'task', title: `موعد نهائي: ${t.title}`, color: t.type === 'work' ? '#3b82f6' : '#10b981' });
        if (t && t.dueDate === dateStr) events.push({ type: 'task', title: `استحقاق: ${t.title}`, color: '#f59e0b' });
      });

      return events;
    };

    return (
      <div className="grid grid-cols-7 gap-px bg-white/5 border border-white/5 rounded-2xl overflow-hidden">
        {calendarDays.map((day, i) => {
          const events = getEventsForDay(day);
          const isSelected = isSameDay(day, selectedDate);
          const isCurrentMonth = isSameMonth(day, monthStart);
          const isToday = isSameDay(day, new Date());

          return (
            <div
              key={i}
              onClick={() => setSelectedDate(day)}
              className={cn(
                "min-h-[120px] p-2 transition-all cursor-pointer relative group",
                isCurrentMonth ? "bg-[#0a0a0a]" : "bg-[#050505] opacity-30",
                isSelected && "bg-brand-500/5 ring-1 ring-inset ring-brand-500/20"
              )}
            >
              <div className="flex justify-between items-start mb-2">
                <span className={cn(
                  "text-sm font-bold w-7 h-7 flex items-center justify-center rounded-full transition-colors",
                  isToday ? "bg-brand-500 text-white" : "text-white/60 group-hover:text-white"
                )}>
                  {format(day, 'd')}
                </span>
              </div>
              
              <div className="space-y-1">
                {events.slice(0, 3).map((event, idx) => (
                  <div 
                    key={idx} 
                    className="text-[9px] px-1.5 py-0.5 rounded truncate font-medium"
                    style={{ backgroundColor: `${event.color}20`, color: event.color, border: `1px solid ${event.color}30` }}
                  >
                    {event.title}
                  </div>
                ))}
                {events.length > 3 && (
                  <div className="text-[8px] text-white/30 font-bold pr-1">+{events.length - 3} المزيد</div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    );
  };

  return (
    <div className="space-y-8">
      {renderHeader()}
      
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        <div className="lg:col-span-3">
          {renderDays()}
          {renderCells()}
        </div>

        <div className="space-y-6">
          <div className="glass-card p-6">
            <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
              <Clock size={18} className="text-brand-400" />
              أجندة اليوم
            </h3>
            <div className="space-y-4">
              <div className="text-xs text-white/40 font-bold uppercase">
                {format(selectedDate, 'EEEE, d MMMM', { locale: ar })}
              </div>
              
              <div className="space-y-3">
                {[
                  { time: '08:00', title: 'مراجعة هندسة البرمجيات', type: 'study' },
                  { time: '11:00', title: 'اجتماع الفريق الأسبوعي', type: 'work' },
                  { time: '14:00', title: 'جلسة فريلانس عميقة', type: 'freelance' },
                  { time: '17:00', title: 'تمرين رياضي', type: 'lifestyle' },
                ].map((item, i) => (
                  <div key={i} className="flex gap-3 group">
                    <div className="text-[10px] font-bold text-white/30 pt-1 w-10">{item.time}</div>
                    <div className="flex-1 p-3 rounded-xl bg-white/5 border border-white/5 group-hover:border-brand-500/20 transition-all">
                      <div className="text-xs font-bold">{item.title}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="glass-card p-6 bg-brand-500/5 border-brand-500/10">
            <h4 className="font-bold mb-2 flex items-center gap-2">
              <CalendarIcon size={16} className="text-brand-400" />
              توزيع ذكي
            </h4>
            <p className="text-xs text-white/60 leading-relaxed">
              تم توزيع مهامك تلقائياً بناءً على مستويات الطاقة المعتادة لديك. تم وضع المهام الصعبة في الصباح الباكر.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CalendarView;
